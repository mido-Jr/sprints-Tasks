#ifndef SIMPLE_LOGGER_H
#define SIMPLE_LOGGER_H

#include <boost/log/trivial.hpp>
#include <boost/log/sources/global_logger_storage.hpp>

// Define the file path for log output
#define LOGFILE "/home/mido/valeo/File_Handler_Task/run_logs.txt"

// Set the threshold for logging severity
#define SEVERITY_THRESHOLD logging::trivial::warning

// Register a global logger instance
BOOST_LOG_GLOBAL_LOGGER(logger, boost::log::sources::severity_logger_mt<boost::log::trivial::severity_level>)

// Helper macro for logging, do not use directly in your code
#define LOG(severity) BOOST_LOG_SEV(logger::get(), boost::log::trivial::severity)

// Logging macros for different severity levels
#define LOG_TRACE   BOOST_LOG_TRIVIAL(trace)
#define LOG_INFO    BOOST_LOG_TRIVIAL(info)
#define LOG_WARNING BOOST_LOG_TRIVIAL(warning)
#define LOG_ERROR   BOOST_LOG_TRIVIAL(error)
#define LOG_WARNING BOOST_LOG_TRIVIAL(warning)
#define LOG_ERROR   BOOST_LOG_TRIVIAL(error)
#define LOG_FATAL   BOOST_LOG_TRIVIAL(fatal)

#endif // SIMPLE_LOGGER_H

