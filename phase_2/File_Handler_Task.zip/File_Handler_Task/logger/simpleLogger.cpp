#include "simpleLogger.h" 
#include <fstream>
#include <ostream>
#include <iomanip>
#include <boost/log/core.hpp>
#include <boost/log/expressions/formatters/date_time.hpp>
#include <boost/log/expressions.hpp>
#include <boost/log/sinks/sync_frontend.hpp>
#include <boost/log/sinks/text_ostream_backend.hpp>
#include <boost/log/sources/severity_logger.hpp>
#include <boost/log/support/date_time.hpp>
#include <boost/log/trivial.hpp>
#include <boost/core/null_deleter.hpp>
#include <boost/log/utility/setup/common_attributes.hpp>
#include <boost/make_shared.hpp>
#include <boost/shared_ptr.hpp>


namespace logging = boost::log;
namespace src = boost::log::sources;
namespace expr = boost::log::expressions;
namespace sinks = boost::log::sinks;
namespace attrs = boost::log::attributes;

void initLogger() {
    logging::core::get()->set_filter(logging::trivial::severity >= logging::trivial::info);

    typedef sinks::synchronous_sink<sinks::text_ostream_backend> text_sink;
    boost::shared_ptr<text_sink> sink = boost::make_shared<text_sink>();

    // Attach a logfile stream to the sink
    sink->locked_backend()->add_stream(boost::make_shared<std::ofstream>(LOGFILE));

    // Attach a console output stream to the sink
    sink->locked_backend()->add_stream(boost::shared_ptr<std::ostream>(&std::cout, [](std::ostream*){}));

    // Define the log message format
    logging::formatter formatter = boost::log::expressions::stream
        << std::setw(7) << std::setfill('0') << expr::attr<unsigned int>("LineID") << std::setfill(' ') << " | "
        << expr::format_date_time(boost::log::expressions::attr<boost::posix_time::ptime>("TimeStamp"), "%Y-%m-%d, %H:%M:%S.%f") << " "
        << "[" << logging::trivial::severity << "]"
        << " - " << expr::smessage;
    sink->set_formatter(formatter);

    // Register the sink with the logging core
    logging::core::get()->add_sink(sink);
}
int main() {
    initLogger();

    BOOST_LOG_TRIVIAL(info) << "Starting the program.";
    BOOST_LOG_TRIVIAL(warning) << "This is a warning.";
    BOOST_LOG_TRIVIAL(error) << "This is an error.";

    return 0;
}

