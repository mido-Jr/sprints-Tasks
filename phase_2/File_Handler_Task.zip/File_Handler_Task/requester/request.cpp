#include <iostream>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <semaphore.h>
#include <string>
#include <sys/shm.h>
#include "../logger/simpleLogger.h"


#define BackingFile "/my_shared_memory_file"
#define AccessPerms 0644
#define ByteSize 1024
#define SemaphoreName "/my_semaphore"
#define MemContents "Hello, Shared Memory!"

void report_and_exit(const char* msg) {
    perror(msg);
    exit(-1);
}

int main(int argc, char* argv[]) {
    LOG_TRACE << "Starting the program.";

    if (argc != 2) {
        std::cerr << "Usage: " << argv[0] << " <-r or -l>" << std::endl;
        return -1;
    }

    int value;
    if (strcmp(argv[1], "-r") == 0) {
        value = 0;
    } else if (strcmp(argv[1], "-l") == 0) {
        value = 1;
    } else {
        std::cerr << "Invalid argument. Please provide -r or -l." << std::endl;
        return -1;
    }

    const char* pipeName = "../fifoChannel";
    mkfifo(pipeName, 0666);
    int fdPipe = open(pipeName, O_CREAT | O_WRONLY);
    if (fdPipe < 0) {
        LOG_ERROR << "Failed to open the pipe.";
        return -1;
    }

    write(fdPipe, &value, sizeof(int));
    close(fdPipe);
    unlink(pipeName);
    LOG_INFO << "Value " << value << " sent to the pipe.";

    sleep(3);

    /* Shared Memory */
    int fdSharedMem = shm_open(BackingFile, O_RDWR, AccessPerms);
    if (fdSharedMem < 0) {
        report_and_exit("Can't get file descriptor for shared memory.");
    }

    void* memptr = mmap(nullptr, ByteSize, PROT_READ | PROT_WRITE, MAP_SHARED, fdSharedMem, 0);
    if (memptr == MAP_FAILED) {
        report_and_exit("Can't access shared memory segment.");
    }

    sem_t* semptr = sem_open(SemaphoreName, O_CREAT, AccessPerms, 0);
    if (semptr == SEM_FAILED) {
        report_and_exit("Failed to open the semaphore.");
    }

    if (!sem_wait(semptr)) {
        for (int i = 0; i < strlen(MemContents); i++) {
            write(STDOUT_FILENO, static_cast<char*>(memptr) + i, 1);
        }
        sem_post(semptr);
    }

    // Cleanup
    munmap(memptr, ByteSize);
    close(fdSharedMem);
    sem_close(semptr);
    unlink(BackingFile);

    LOG_WARNING << "Exiting the program.";
    return 0;
}

