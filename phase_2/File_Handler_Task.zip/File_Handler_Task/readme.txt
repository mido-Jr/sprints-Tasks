Run the "requester" program with the -l option for one scenario:
 --> ./requester -l

Or run it with the -r option for another scenario:
 --> ./requester -r


Then Run the "fh" program:
 --> ./fh
