#include <iostream>
#include <fstream>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <semaphore.h>
#include <cstring>
#include "../logger/simpleLogger.h" // Include your logger header here

#define BackingFile "/my_shared_memory_file"
#define AccessPerms 0644
#define ByteSize 1024
#define SemaphoreName "/my_semaphore"

void report_and_exit(const char* msg) {
    perror(msg);
    exit(-1);
}

int main() {
    LOG_WARNING << "Starting the program.";

    const char* fifoFile = "../fifoChannel";
    int fdFifo = open(fifoFile, O_RDONLY);
    if (fdFifo < 0) {
        LOG_ERROR << "Failed to open the FIFO.";
        return -1;
    }

    int value;
    ssize_t count = read(fdFifo, &value, sizeof(int));
    if (count != sizeof(int)) {
        LOG_ERROR << "Error reading from the FIFO.";
        close(fdFifo);
        return -1;
    }

    close(fdFifo); // Close pipe from read end
    unlink(fifoFile); // Unlink from the underlying file
    LOG_INFO << "Received value from FIFO: " << value;

    /* Shared Memory */
    int fdSharedMem = shm_open(BackingFile, O_RDWR | O_CREAT, AccessPerms);
    if (fdSharedMem < 0) {
        report_and_exit("Can't open shared memory segment...");
    }

    ftruncate(fdSharedMem, ByteSize);

    void* memptr = mmap(nullptr, ByteSize, PROT_READ | PROT_WRITE, MAP_SHARED, fdSharedMem, 0);
    if (memptr == MAP_FAILED) {
        report_and_exit("Can't get shared memory segment...");
    }

    LOG_INFO << "Shared memory address: " << memptr << " [0.." << ByteSize - 1 << "]";
    LOG_INFO << "Backing file: /dev/shm" << BackingFile;

    sem_t* semptr = sem_open(SemaphoreName, O_CREAT, AccessPerms, 0);
    if (semptr == SEM_FAILED) {
        report_and_exit("sem_open");
    }

    if (value == 0) {
        FILE* file = fopen("/home/mido/valeo/File_Handler_Task/test/file.txt", "r");
        if (file == nullptr) {
            report_and_exit("fopen");
        }

        size_t read_size = fread(memptr, 1, ByteSize, file);
        if (read_size > 0 && read_size < ByteSize) {
            static_cast<char*>(memptr)[read_size] = '\0';
        }

        sleep(12);

        fclose(file);
        sem_post(semptr);
    } else if (value == 1) {
        FILE* lsOutput = popen("ls /home/mido/valeo/File_Handler_Task/test", "r");
        if (lsOutput == nullptr) {
            report_and_exit("popen");
        }

        char buffer[ByteSize];
        size_t read_size = fread(buffer, sizeof(char), ByteSize, lsOutput);
        if (read_size > 0) {
            strncpy(static_cast<char*>(memptr), buffer, ByteSize);
        }

        sleep(12);

        pclose(lsOutput);
        sem_post(semptr);
    }

    // Cleanup
    munmap(memptr, ByteSize);
    close(fdSharedMem);
    sem_close(semptr);
    shm_unlink(BackingFile);

    LOG_WARNING << "Exiting the program.";
    return 0;
}

