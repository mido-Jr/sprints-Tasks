#include <gtest/gtest.h>
#include <vector>
#include <string>
#include "../file_handler/fh.cpp"  // Include the header, not the cpp file

namespace fh {
    // Mocked implementations for functions used in tests
    std::vector<std::string> getFileList(const std::string& directoryPath) {
        // Mock implementation: Return a predefined list of files
        return {"file1.txt", "file2.txt", "file3.txt"};
    }

    std::string readFileContent(const std::string& filePath) {
        // Mock implementation: Return predefined file content
        return "File content of " + filePath;
    }
}

// Test case: Test the getFileList function
TEST(FHTests, TestFileListRetrieval) {
    // Mock the directory path
    std::string directoryPath = "/path/to/directory";

    // Call the function to get the file list
    std::vector<std::string> fileList = fh::getFileList(directoryPath);

    // Check if the file list contains expected files
    ASSERT_EQ(fileList.size(), 3);
    EXPECT_EQ(fileList[0], "file1.txt");
    EXPECT_EQ(fileList[1], "file2.txt");
    EXPECT_EQ(fileList[2], "file3.txt");
}

// Test case: Test the readFileContent function
TEST(FHTests, TestReadFileContent) {
    // Mock the file path
    std::string filePath = "/path/to/file.txt";

    // Call the function to read file content
    std::string fileContent = fh::readFileContent(filePath);

    // Check if the returned content matches the mock implementation
    EXPECT_EQ(fileContent, "File content of " + filePath);
}

// Test case: Test reading content of non-existent file
TEST(FHTests, TestReadNonExistentFileContent) {
    // Mock the file path of a non-existent file
    std::string filePath = "/path/to/nonexistent.txt";

    // Call the function to read file content
    std::string fileContent = fh::readFileContent(filePath);

    // Check if the returned content is empty
    EXPECT_EQ(fileContent, "");
}

// Test case: Test empty file list
TEST(FHTests, TestEmptyFileList) {
    // Mock the directory path
    std::string directoryPath = "/path/to/empty_directory";

    // Call the function to get the file list
    std::vector<std::string> fileList = fh::getFileList(directoryPath);

    // Check if the file list is empty
    EXPECT_TRUE(fileList.empty());
}

// Add more test cases as needed

int main(int argc, char** argv) {
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}

