#!/bin/bash
echo  "Welcome, this script created by Mido :)"

source_directory="/source_directory"
backup_directory="/backup"
timestamp=$(date +"%Y-%m-%d")
backup_path="$backup_directory/backup_$timestamp"

rsync -a --delete --link-dest="$backup_directory/latest" "$source_directory/" "$backup_path"

rm -f "$backup_directory/latest"
ln -s "$backup_path" "$backup_directory/latest"

cd "$backup_directory"
ls -dt backup_* | tail -n +6 | xargs -d '\n' rm -r

exit 0
