#!/bin/bash

# Get the list of available WiFi networks
networks=$(nmcli -t -f SSID,SIGNAL device wifi | grep -vE '^lo')

# Check if there are no available networks
if [ -z "$networks" ]; then
  echo "Can't recommend any WIFI network."
else
  # Initialize the best network
  best_network=""
  best_signal=0

  # Loop through the networks
  while IFS=: read -r ssid signal; do
    if [ -n "$ssid" ]; then  # Skip hidden networks
      if [ $signal -gt $best_signal ]; then
        best_network="$ssid"
        best_signal="$signal"
      fi
    fi
  done <<< "$networks"

  # Check if a valid network was found
  if [ -n "$best_network" ]; then
    echo "The best WiFi network to connect to is $best_network with signal $best_signal"
  else
    echo "Can't recommend any WIFI network."
  fi
fi
