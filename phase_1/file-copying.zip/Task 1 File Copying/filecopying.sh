#! bin/bash
echo  "Welcome, this script created by Mido :)"

if [ ! -d "$2" ]; then
  echo "The destination path does not exist. Creating it..."
  mkdir "$2"
fi

cp "$1" "$2"

echo "The Job Done, See You!"
